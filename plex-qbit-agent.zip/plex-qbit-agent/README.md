# Plex Download Agent

A tiny self-hosted chat page: type what you want, a local LLM (via
[Ollama](https://ollama.com)) turns that into a search query, qBittorrent
searches for it, you pick from the top 3 (most-seeded, deduplicated) results,
and the page tracks the download's progress and destination folder until
it's done -- ready for Plex to pick up.

**Only use this to fetch content you actually have the rights to** (things
you own, Linux ISOs, public-domain media, content you're licensed to
redistribute, your own recordings, etc.) -- it is generic automation glue
around qBittorrent's own search feature, not a source of content itself.

## Assumes you already run qBittorrent

This compose file does **not** start a qBittorrent container -- it's built
to sit next to an existing qBittorrent instance (e.g. one already running
through Gluetun/a VPN in another compose stack, as on `puck-plex`). The
`app` service just talks to whatever qBittorrent WebUI you point it at
over the network.

If you *don't* already have qBittorrent running somewhere, add a service
for it yourself (linuxserver's `qbittorrent` image is the usual choice)
and point `QBIT_HOST` at it.

## What's in the box

| Service       | Role                                                            |
|---------------|------------------------------------------------------------------|
| `ollama`      | Runs the local LLM used to parse your chat messages.             |
| `ollama-pull` | One-shot job that pulls the model on first `docker compose up`.  |
| `app`         | FastAPI backend + the chat web page (this is what you open in a browser). |

The `app` container never talks to any torrent site directly -- it only
calls qBittorrent's own `/api/v2/search/*` and `/api/v2/torrents/*` WebUI
API. Which sites it can search depends entirely on which **search
plugins** you already have installed inside qBittorrent.

## Setup

### 1. Configure

```bash
cp .env.example .env
```

Edit `.env`:
- `LAN_IP` / `QBIT_WEBUI_PORT` -- where your existing qBittorrent WebUI
  actually lives (on `puck-plex` that's `192.168.1.8` / `8080`, published
  by the `gluetun` service).
- `QBIT_USERNAME` / `QBIT_PASSWORD` -- the **real** WebUI login you
  already use to log into that qBittorrent today. This isn't something
  this project can guess -- check Settings > WebUI in the qBittorrent UI
  if you're not sure, or reset it there.
- `QBIT_SAVE_PATH` -- the save directory as **qBittorrent's own container**
  sees it (not a path on this machine). See "Making downloads show up in
  Plex" below -- this matters more than it sounds like it should.
- `OLLAMA_MODEL` -- defaults to `llama3.2`. Any small instruction-tuned
  model works fine for this (e.g. `qwen2.5:3b`, `mistral`); bigger just
  means slower query parsing for no real benefit here.

### 2. Start everything

```bash
docker compose up -d
```

First boot will take a few minutes while the `ollama-pull` job downloads
the model. Watch it with:

```bash
docker compose logs -f ollama-pull
```

### 3. Open the chat page

Go to `http://<LAN_IP>:<APP_PORT>` (defaults to `http://192.168.1.8:5000`).
Try something like:

> get me the matrix 1999

The agent will show you a "connected/unreachable" status for both
qBittorrent and the LLM at the top -- check that first if something
seems off.

## Making downloads show up in Plex

Per your existing `puck-plex` compose file, Plex only scans
`/mnt/usbdrive/TV` and `/mnt/usbdrive/Movies` -- it does **not** scan the
general `/downloads` folder qBittorrent also has mounted. So where you
point `QBIT_SAVE_PATH` decides what happens next:

- `QBIT_SAVE_PATH=/downloads` (the default) -- lands in the shared
  Downloads folder like any other manual grab. Won't appear in Plex until
  you move it into the right folder yourself (or let Sonarr/Radarr, which
  you already run, pick it up if it's monitoring that folder).
- `QBIT_SAVE_PATH=/mnt/usbdrive/Movies` -- shows up in Plex as soon as the
  download finishes and Plex rescans. Only sensible if you'll mostly use
  this agent for movies.
- `QBIT_SAVE_PATH=/mnt/usbdrive/TV` -- same, but for TV.

This agent doesn't do TV/movie classification or renaming the way
Sonarr/Radarr do -- it's a manual "grab this specific thing now" tool, not
a replacement for your existing automated pipeline. If you want one
`QBIT_SAVE_PATH` that works for both, keep it at `/downloads` and just
move finished files into place (or into Sonarr/Radarr's "Manual Import")
yourself.

## How the request flow works

1. **Chat -> query.** Your message is sent to the local LLM with a prompt
   asking it to strip filler ("could you please grab me...") and return a
   clean search string. If the LLM is unreachable, a simple heuristic
   cleanup is used instead so the app keeps working.
2. **Query -> qBittorrent search.** The backend calls
   `POST /api/v2/search/start`, polls `/api/v2/search/status` until it
   finishes (or a timeout, default 20s -- tune with
   `SEARCH_TIMEOUT_SECONDS`), then fetches `/api/v2/search/results`.
3. **Top 3.** Results are deduplicated by name (keeping the highest-seed
   copy of each) and sorted by seed count, descending. Top 3 are shown as
   clickable cards with seeds / leechers / size / source.
4. **Pick -> download.** Clicking a card calls
   `POST /api/v2/torrents/add` with that result's magnet/torrent link and
   your configured `QBIT_SAVE_PATH`, tagged internally so the app can find
   its torrent hash and start polling it.
5. **Status.** The page polls `GET /api/v2/torrents/info` every 2 seconds
   per active download and shows a progress bar, %, state, ETA, and the
   save directory until it hits 100%.

## Notes & tuning

- **Multiple downloads at once** are supported -- each pick gets its own
  tracked card in the right-hand column.
- **No login page** -- this is meant for your local network only, which is
  why the app is bound to `LAN_IP` rather than `0.0.0.0`, matching how the
  rest of your admin UIs are published. Don't expose it further without
  adding your own auth/reverse-proxy in front.
- **GPU for Ollama:** if you have an NVIDIA GPU, uncomment the `deploy:`
  block under the `ollama` service in `docker-compose.yml` and make sure
  the [NVIDIA Container Toolkit](https://docs.nvidia.com/datacenter/cloud-native/container-toolkit/latest/install-guide.html)
  is installed on the host.

## Troubleshooting

- **"qBittorrent login failed"** in `/api/health` -- almost always means
  `QBIT_USERNAME`/`QBIT_PASSWORD` in `.env` don't match qBittorrent's real
  WebUI login. This project never sets or changes that password; it only
  logs in with whatever you already have configured.
- **Can't reach qBittorrent at all** -- confirm `LAN_IP`/`QBIT_WEBUI_PORT`
  in `.env` are right, and that qBittorrent's WebUI is actually reachable
  from another machine on your LAN at `http://<LAN_IP>:<QBIT_WEBUI_PORT>`
  (open it in a browser) before assuming this app is the problem.
- **No search results ever** -- you likely don't have any search plugins
  installed/enabled in qBittorrent (Search tab > Search plugins...), or
  the plugins you have are all down/broken.
- **LLM shows "unreachable"** -- give `ollama-pull` time to finish on
  first boot (`docker compose logs -f ollama-pull`); after that, `docker
  compose logs ollama` for anything unusual.
