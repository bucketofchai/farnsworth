"""
Thin wrapper around the qBittorrent WebUI API (v2).

Only uses generic, documented endpoints:
  - /api/v2/auth/login
  - /api/v2/search/start | status | results | stop
  - /api/v2/torrents/add
  - /api/v2/torrents/info

This module does not know or care which search plugins are installed --
that's configured by the user in the qBittorrent WebUI itself
(Tools > Search Plugins). It just drives whatever plugins are enabled.
"""
from __future__ import annotations

import time
import uuid
from dataclasses import dataclass
from typing import Optional

import httpx


class QbitError(RuntimeError):
    pass


@dataclass
class SearchResult:
    name: str
    size: int
    seeds: int
    leechers: int
    site: str
    link: str  # magnet URI or .torrent download URL, passed straight to torrents/add

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "size": self.size,
            "seeds": self.seeds,
            "leechers": self.leechers,
            "site": self.site,
            "link": self.link,
        }


@dataclass
class TorrentStatus:
    torrent_hash: str
    name: str
    progress_pct: float
    state: str
    eta_seconds: Optional[int]
    dlspeed_bps: int
    save_path: str
    size: int

    def to_dict(self) -> dict:
        return {
            "hash": self.torrent_hash,
            "name": self.name,
            "progress_pct": round(self.progress_pct, 1),
            "state": self.state,
            "eta_seconds": self.eta_seconds,
            "dlspeed_bps": self.dlspeed_bps,
            "save_path": self.save_path,
            "size": self.size,
        }


class QbitClient:
    def __init__(self, host: str, username: str, password: str, timeout: float = 15.0):
        self.host = host.rstrip("/")
        self.username = username
        self.password = password
        self._client = httpx.Client(
            base_url=self.host,
            timeout=timeout,
            headers={"Referer": self.host, "Origin": self.host},
        )
        self._logged_in = False

    # ------------------------------------------------------------------ #
    # Auth
    # ------------------------------------------------------------------ #
    def login(self) -> None:
        resp = self._client.post(
            "/api/v2/auth/login",
            data={"username": self.username, "password": self.password},
        )
        if resp.status_code != 200 or resp.text.strip() != "Ok.":
            raise QbitError(
                f"qBittorrent login failed (status={resp.status_code}, body={resp.text!r}). "
                "Check QBIT_USERNAME / QBIT_PASSWORD."
            )
        self._logged_in = True

    def _ensure_login(self) -> None:
        if not self._logged_in:
            self.login()

    def _request(self, method: str, path: str, **kwargs) -> httpx.Response:
        self._ensure_login()
        resp = self._client.request(method, path, **kwargs)
        if resp.status_code == 403:
            # Session probably expired -- retry once after re-login.
            self.login()
            resp = self._client.request(method, path, **kwargs)
        if resp.status_code >= 400:
            raise QbitError(f"{method} {path} -> HTTP {resp.status_code}: {resp.text[:300]}")
        return resp

    # ------------------------------------------------------------------ #
    # Search
    # ------------------------------------------------------------------ #
    def search_start(self, pattern: str, plugins: str = "enabled", category: str = "all") -> int:
        resp = self._request(
            "POST",
            "/api/v2/search/start",
            data={"pattern": pattern, "plugins": plugins, "category": category},
        )
        data = resp.json()
        search_id = data.get("id")
        if search_id is None:
            raise QbitError(f"search/start did not return an id: {data!r}")
        return search_id

    def search_status(self, search_id: int) -> str:
        resp = self._request("GET", "/api/v2/search/status", params={"id": search_id})
        rows = resp.json()
        if not rows:
            return "Stopped"
        return rows[0].get("status", "Stopped")

    def search_results_raw(self, search_id: int, limit: int = 100) -> list[dict]:
        resp = self._request(
            "GET", "/api/v2/search/results", params={"id": search_id, "limit": limit, "offset": 0}
        )
        return resp.json().get("results", [])

    def search_stop(self, search_id: int) -> None:
        try:
            self._request("POST", "/api/v2/search/stop", data={"id": search_id})
        except QbitError:
            pass  # best-effort; search may have already finished on its own

    def search_and_wait(self, pattern: str, timeout_seconds: float = 20.0) -> list[dict]:
        """Runs a search, polls until it stops or the timeout hits, then stops it."""
        search_id = self.search_start(pattern)
        deadline = time.monotonic() + timeout_seconds
        try:
            while time.monotonic() < deadline:
                if self.search_status(search_id) != "Running":
                    break
                time.sleep(1.0)
        finally:
            self.search_stop(search_id)
        return self.search_results_raw(search_id)

    @staticmethod
    def top_matches(raw_results: list[dict], count: int = 3) -> list[SearchResult]:
        """Sorts by seed count (desc) and dedupes by name, keeping the
        highest-seeded copy of each unique name."""
        best_by_name: dict[str, dict] = {}
        for row in raw_results:
            name = (row.get("fileName") or "").strip()
            if not name:
                continue
            key = " ".join(name.lower().split())  # normalize whitespace/case
            seeds = row.get("nbSeeders") or 0
            existing = best_by_name.get(key)
            if existing is None or seeds > (existing.get("nbSeeders") or 0):
                best_by_name[key] = row

        ordered = sorted(best_by_name.values(), key=lambda r: r.get("nbSeeders") or 0, reverse=True)
        results = []
        for row in ordered[:count]:
            link = row.get("fileUrl") or row.get("descrLink") or ""
            results.append(
                SearchResult(
                    name=row.get("fileName") or "Unknown",
                    size=row.get("fileSize") or 0,
                    seeds=row.get("nbSeeders") or 0,
                    leechers=row.get("nbLeechers") or 0,
                    site=row.get("siteUrl") or "",
                    link=link,
                )
            )
        return results

    # ------------------------------------------------------------------ #
    # Adding / tracking torrents
    # ------------------------------------------------------------------ #
    def add_torrent(self, link: str, save_path: str) -> str:
        """Adds a torrent/magnet and returns its info-hash for status polling.

        qBittorrent's torrents/add endpoint doesn't return the new hash
        directly, so we tag the add with a unique marker and look it up
        right after.
        """
        tag = f"plexagent-{uuid.uuid4().hex[:12]}"
        self._request(
            "POST",
            "/api/v2/torrents/add",
            data={
                "urls": link,
                "savepath": save_path,
                "tags": tag,
                "autoTMM": "false",
            },
        )

        # The torrent may take a moment to register; poll briefly for it.
        deadline = time.monotonic() + 10.0
        while time.monotonic() < deadline:
            matches = self._torrents_info(tag=tag)
            if matches:
                return matches[0]["hash"]
            time.sleep(0.5)

        raise QbitError(
            "Torrent was submitted to qBittorrent but couldn't be located afterwards "
            "(no torrent found with the expected tag)."
        )

    def _torrents_info(self, tag: Optional[str] = None, torrent_hash: Optional[str] = None) -> list[dict]:
        params = {}
        if tag:
            params["tag"] = tag
        if torrent_hash:
            params["hashes"] = torrent_hash
        resp = self._request("GET", "/api/v2/torrents/info", params=params)
        return resp.json()

    def get_status(self, torrent_hash: str) -> TorrentStatus:
        matches = self._torrents_info(torrent_hash=torrent_hash)
        if not matches:
            raise QbitError(f"No torrent found with hash {torrent_hash}")
        row = matches[0]
        eta = row.get("eta")
        # qBittorrent reports an enormous placeholder ETA (8640000s = 100 days)
        # when it can't estimate yet -- surface that as "unknown" instead.
        eta_seconds = None if eta is None or eta >= 8640000 else int(eta)
        return TorrentStatus(
            torrent_hash=row["hash"],
            name=row.get("name", ""),
            progress_pct=float(row.get("progress", 0.0)) * 100.0,
            state=row.get("state", "unknown"),
            eta_seconds=eta_seconds,
            dlspeed_bps=int(row.get("dlspeed", 0)),
            save_path=row.get("save_path", ""),
            size=int(row.get("size", 0)),
        )
