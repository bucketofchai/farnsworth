"""
Minimal client for a local Ollama instance.

Used for exactly one thing: turning a free-form chat message ("can you grab
me the matrix from 99, the remastered one if possible") into a short,
clean search string qBittorrent's search plugins can actually use, plus a
one-line conversational acknowledgement to show in the chat.

If the LLM is unreachable or returns something we can't parse, we fall
back to a simple heuristic so the app still works.
"""
from __future__ import annotations

import json
import logging
import re

import httpx

logger = logging.getLogger("plex-agent.llm")

_SYSTEM_PROMPT = """You are a search-query extractor for a personal media \
download assistant. Given a user's chat message asking for a movie, TV \
episode, or other media, respond with ONLY a JSON object (no markdown, no \
commentary) with exactly these two keys:

  "query": a short, clean search string suitable for a torrent search \
engine -- just the title and, if mentioned, the year or season/episode. \
Strip out greetings, filler words, and politeness ("can you grab me", \
"please", "thanks").
  "reply": one short, friendly sentence telling the user you're searching \
for that title now.

Example input: "hey could you please snag The Matrix 1999 for me"
Example output: {"query": "The Matrix 1999", "reply": "Sure thing -- searching for The Matrix (1999) now."}
"""

_FILLER_PATTERN = re.compile(
    r"^\s*(hey|hi|hello|yo|ok|okay)\b[,!]?\s*|"
    r"\b(can|could|would)\s+you\s+(please\s+)?|"
    r"\bplease\b|\bthanks?\b|\bthank you\b|\bfor me\b|\bi want\b|\bi'd like\b|"
    r"\bget me\b|\bgrab me\b|\bfind me\b|\bdownload\b|\bsearch for\b",
    re.IGNORECASE,
)


def _heuristic_fallback(message: str) -> dict:
    cleaned = _FILLER_PATTERN.sub(" ", message)
    cleaned = re.sub(r"\s+", " ", cleaned).strip(" .,!?") or message.strip()
    return {"query": cleaned, "reply": f"Searching for \"{cleaned}\" now."}


class LlmClient:
    def __init__(self, host: str, model: str, timeout: float = 30.0):
        self.host = host.rstrip("/")
        self.model = model
        self._client = httpx.Client(base_url=self.host, timeout=timeout)

    def extract_search_query(self, user_message: str) -> dict:
        """Returns {"query": str, "reply": str}. Never raises -- falls back
        to a heuristic on any error so a flaky/missing LLM never blocks the
        core download flow."""
        try:
            resp = self._client.post(
                "/api/generate",
                json={
                    "model": self.model,
                    "prompt": f"{_SYSTEM_PROMPT}\n\nUser message: {user_message!r}",
                    "stream": False,
                    "format": "json",
                    "options": {"temperature": 0.1},
                },
            )
            resp.raise_for_status()
            raw = resp.json().get("response", "")
            parsed = json.loads(raw)
            query = str(parsed.get("query", "")).strip()
            reply = str(parsed.get("reply", "")).strip()
            if not query:
                raise ValueError("empty query from LLM")
            if not reply:
                reply = f"Searching for \"{query}\" now."
            return {"query": query, "reply": reply}
        except Exception as exc:  # noqa: BLE001 -- deliberately broad, this is a fallback path
            logger.warning("LLM query extraction failed (%s); falling back to heuristic", exc)
            return _heuristic_fallback(user_message)

    def ping(self) -> bool:
        try:
            resp = self._client.get("/api/tags", timeout=3.0)
            return resp.status_code == 200
        except Exception:  # noqa: BLE001
            return False
