"""
FastAPI backend for the Plex download chat agent.

Flow:
  1. POST /api/chat        -- user's chat message -> local LLM cleans it into
                               a search query -> qBittorrent search -> top 3
                               unique results sorted by seed count.
  2. POST /api/download    -- user's chosen result -> added to qBittorrent,
                               returns a torrent hash to poll.
  3. GET  /api/status/{h}  -- current % progress, ETA, state, save directory.
"""
from __future__ import annotations

import logging
import os

from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from llm_client import LlmClient
from qbit_client import QbitClient, QbitError

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("plex-agent")

# --------------------------------------------------------------------------- #
# Config (all overridable via environment / docker-compose.yml)
# --------------------------------------------------------------------------- #
OLLAMA_HOST = os.environ.get("OLLAMA_HOST", "http://localhost:11434")
OLLAMA_MODEL = os.environ.get("OLLAMA_MODEL", "llama3.2")
QBIT_HOST = os.environ.get("QBIT_HOST", "http://localhost:8080")
QBIT_USERNAME = os.environ.get("QBIT_USERNAME", "admin")
QBIT_PASSWORD = os.environ.get("QBIT_PASSWORD", "adminadmin")
QBIT_SAVE_PATH = os.environ.get("QBIT_SAVE_PATH", "/downloads")
SEARCH_TIMEOUT_SECONDS = float(os.environ.get("SEARCH_TIMEOUT_SECONDS", "20"))

app = FastAPI(title="Plex Download Agent")

llm = LlmClient(host=OLLAMA_HOST, model=OLLAMA_MODEL)
qbit = QbitClient(host=QBIT_HOST, username=QBIT_USERNAME, password=QBIT_PASSWORD)


# --------------------------------------------------------------------------- #
# Request/response models
# --------------------------------------------------------------------------- #
class ChatRequest(BaseModel):
    message: str


class ChatResponse(BaseModel):
    reply: str
    query: str
    results: list[dict]


class DownloadRequest(BaseModel):
    name: str
    link: str


class DownloadResponse(BaseModel):
    hash: str
    name: str


# --------------------------------------------------------------------------- #
# Routes
# --------------------------------------------------------------------------- #
@app.get("/api/health")
def health():
    qbit_ok = True
    qbit_error = None
    try:
        qbit.login()
    except QbitError as exc:
        qbit_ok = False
        qbit_error = str(exc)
    return {
        "qbittorrent": {"ok": qbit_ok, "error": qbit_error, "host": QBIT_HOST},
        "ollama": {"ok": llm.ping(), "host": OLLAMA_HOST, "model": OLLAMA_MODEL},
    }


@app.post("/api/chat", response_model=ChatResponse)
def chat(req: ChatRequest):
    message = req.message.strip()
    if not message:
        raise HTTPException(400, "Empty message")

    extracted = llm.extract_search_query(message)
    query = extracted["query"]
    reply = extracted["reply"]

    try:
        raw_results = qbit.search_and_wait(query, timeout_seconds=SEARCH_TIMEOUT_SECONDS)
    except QbitError as exc:
        logger.exception("qBittorrent search failed")
        raise HTTPException(502, f"qBittorrent search failed: {exc}") from exc

    top3 = qbit.top_matches(raw_results, count=3)

    if not top3:
        reply += " ...but I didn't find any results. Try rephrasing, or check that " \
                  "you have search plugins installed in qBittorrent (Tools > Search Plugins)."

    return ChatResponse(reply=reply, query=query, results=[r.to_dict() for r in top3])


@app.post("/api/download", response_model=DownloadResponse)
def download(req: DownloadRequest):
    try:
        torrent_hash = qbit.add_torrent(req.link, save_path=QBIT_SAVE_PATH)
    except QbitError as exc:
        logger.exception("Failed to add torrent")
        raise HTTPException(502, f"Failed to start download: {exc}") from exc
    return DownloadResponse(hash=torrent_hash, name=req.name)


@app.get("/api/status/{torrent_hash}")
def status(torrent_hash: str):
    try:
        return qbit.get_status(torrent_hash).to_dict()
    except QbitError as exc:
        raise HTTPException(404, str(exc)) from exc


# --------------------------------------------------------------------------- #
# Static frontend (single simple chat page)
# --------------------------------------------------------------------------- #
STATIC_DIR = os.path.join(os.path.dirname(__file__), "static")
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")


@app.get("/")
def index():
    return FileResponse(os.path.join(STATIC_DIR, "index.html"))
